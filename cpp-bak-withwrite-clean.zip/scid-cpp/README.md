# scidtopgn - SCID to PGN Converter

A standalone C++ CLI tool that converts SCID chess database files to PGN format.

## Usage

```bash
scidtopgn <database_path>
```

Where `<database_path>` is the base name of SCID database (without file extensions).

### Example

```bash
scidtopgn mygames
```

This reads `mygames.si4`, `mygames.sn4`, and `mygames.sg4` and outputs PGN to stdout.

### Save to File

```bash
scidtopgn mygames > output.pgn
```

### Example Output

```pgn
[Event "World Championship"]
[Site "London"]
[Date "2023.04.15"]
[Round "1"]
[White "Magnus Carlsen"]
[Black "Fabiano Caruana"]
[Result "1-0"]
[WhiteElo "2853"]
[BlackElo "2820"]
[ECO "C50"]

1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 5. d3 d6 6. c3 a6 7. a4 Ba7
8. Re1 h6 9. h3 O-O 10. Nbd2 Be6 11. Bxe6 fxe6 12. b4 Nd7 13. Qb3 Nb6
14. a5 Nc4 15. Nxc4 Bxc4 16. d4 exd4 17. cxd4 Bxd4 18. Nxd4 Qxd4 19. Rd1 Qc5
20. Qxc5 Nxc5 21. Rxe6 Rad8 22. Re7 Kh8 23. Rxa7 Rxd4 24. Rxa6 Nxe4 25. Ra8+ Kg7
26. Rxe8 Rd1+ 27. Kh2 Rd7 28. b5 c6 29. Rc8 Rb5 30. Rxc6 Rb2 31. Kg3 Nxg5
32. fxg5 Rxg5+ 33. Kf4 g5+ 34. Ke3 Rf5 35. Rd8 h5 36. Rd3 Rf1 37. Kf3 Kf6
38. Kg4 h4 39. Rd6+ Ke5 40. Rd8 Ke7 41. Kh5 Rf5 42. Kh4 Rxg5+ 43. Kxg5 Kf7
44. Rd7+ Ke6 45. Rd8 Ke7 46. Kf4 Kf8 47. Ke5 Kg7 48. Kd6 Kf7 49. Rd7+ Ke8
50. Kc7 1-0
```

## Features

- ✅ Reads SCID database files (.si4, .sn4, .sg4)
- ✅ Converts all games to standard PGN format
- ✅ Includes all PGN tags (Event, Site, Date, Round, White, Black, Result, ELO, ECO, etc.)
- ✅ Handles variations (with parentheses)
- ✅ Includes comments (in braces)
- ✅ Supports NAGs (Numeric Annotation Glyphs) like !, ?, !?
- ✅ Handles special positions (FEN tags for non-standard starts)
- ✅ Skips deleted games
- ✅ Uses original SCID PGN output logic (100% compatible)

## Building

### Initial Setup (One-time)

From the project root directory:

```bash
# Run setup script to copy SCID source files
./setup.sh
```

This copies 31 required files from the original SCID codebase to `scid-cpp/scid/`.

### Build from Source

```bash
cd scid-cpp
mkdir build
cd build
cmake ..
make
```

### Clean Build

```bash
cd scid-cpp
rm -rf build
mkdir build
cd build
cmake ..
make
```

### Install (Optional)

```bash
cd scid-cpp/build
sudo make install
```

This installs the `scidtopgn` executable to `/usr/local/bin/`.

## Requirements

- C++17 or later
- CMake 3.15 or later
- SCID source files (copied by setup.sh)

## Project Structure

```
scid-cpp/
├── src/              # Tool source code
│   └── main.cpp      # CLI entry point
├── scid/             # Copied SCID source files
│   ├── game.cpp/h    # Game decoding and PGN output
│   ├── index.cpp/h   # Index file handling
│   ├── namebase.cpp/h # Name file handling
│   └── ...          # Other SCID files
├── build/            # Build output (created by CMake)
├── CMakeLists.txt    # Build configuration
└── README.md         # This file
```

## PGN Features

The tool outputs full PGN format including:

### Standard Tags
- Event, Site, Date, Round, White, Black, Result
- WhiteElo, BlackElo
- ECO code
- Additional custom tags if present

### Move Notation
- Standard Algebraic Notation (SAN)
- Move numbers (1. e4 e5 2. Nf3...)
- Check and mate symbols (+ and #)

### Annotations
- Comments in braces: {excellent move}
- NAGs: !, ?, !!, ??, !?, $1-$255
- Variations in parentheses: (1. e4 e5 2. Nf3 (2. d4) Nc6)

### Special Cases
- Castling: O-O, O-O-O
- Pawn promotions: e8=Q
- En passant: exd6
- Non-standard starting positions: [FEN "..."]

## Testing

### Test with Sample Database

```bash
# Assuming you have a test SCID database called "testdb"
cd scid-cpp/build
./scidtopgn ../../testdb > test_output.pgn

# Verify output
head -20 test_output.pgn
```

### Verify PGN Format

You can verify the PGN output with chess engines:

```bash
# Using pgn-extract (if available)
pgn-extract -s test_output.pgn

# Or using Stockfish (to validate games)
stockfish test_output.pgn
```

## Troubleshooting

### "cannot open index file" Error

Ensure the database files exist:
```bash
ls -l mygames.si4 mygames.sn4 mygames.sg4
```

### "cannot read name file" Error

Check that all three files have the same base name.

### Compilation Errors

Ensure you have C++17 support:
```bash
g++ --version  # Should show version 7.0 or later
```

### "undefined reference" Errors

Ensure all SCID files were copied during setup:
```bash
ls scid/*.cpp scid/*.h
```

You should see 31 files:
```
attacks.h
common.h
date.cpp
date.h
error.h
game.cpp
game.h
gfile.cpp
gfile.h
index.cpp
index.h
misc.cpp
misc.h
mfile.cpp
mfile.h
movelist.cpp
movelist.h
namebase.cpp
namebase.h
position.cpp
position.h
sqlist.h
sqmove.h
sqset.h
stralloc.cpp
stralloc.h
textbuf.cpp
textbuf.h
```

If files are missing, re-run the setup:
```bash
cd ..
./setup.sh
```

## License

Uses SCID source code. Original SCID license applies to reused code.

## Acknowledgments

- SCID: Shane's Chess Information Database
- PGN format: Portable Game Notation Standard
